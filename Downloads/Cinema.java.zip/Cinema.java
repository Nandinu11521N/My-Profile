import java.util.*;
class Cinema {
	
	public static void main (String[] args) {
		Scanner input=new Scanner(System.in);
		System.out.println("=================================================================================");
        System.out.println("||\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t||");
        System.out.println("||\t\t\t\t   =*%@@%*= \t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t||");
        System.out.println("||\t\t\t\t   =@@@@@@@@@= \t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t||");
        System.out.println("||\t\t .=#@@#=.	 =@@@@@@@@@@@@@= \t\t\t\t\t\t\t\t\t\t\t\t\t\t\t||");
        System.out.println("||\t\t :@@@@@@@@-	 @@@@@@@@@@@@@@@% \t\t\t\t\t\t\t\t\t\t\t\t\t\t||");
        System.out.println("||\t\t @@@@@@@@@@	 =@@@@@@@@@@@@@@= \t\t\t\t\t\t\t\t\t\t\t\t\t\t||");
        System.out.println("||\t\t :@@@@@@@@-	  +@@@@@@@@@@@@= \t\t\t\t\t\t\t\t\t\t\t\t\t\t||");
        System.out.println("||\t\t  .+#@@#+.	    =*%@@%*= \t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t||");
        System.out.println("||\t\t =#@@@@@@@@@@@@@@@@@@@@@@@@@@#= \t\t\t\t\t\t\t\t\t\t\t\t\t\t||");
        System.out.println("||\t\t*@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@*   -+%@# \t\t\t\t\t\t\t\t\t\t\t||");
        System.out.println("||\t\t@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ :+#@@@@@@@ \t\t\t\t\t\t\t\t\t\t||");
        System.out.println("||\t\t@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ \t\t\t\t\t\t\t\t\t\t||"); 
        System.out.println("||\t\t@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ \t\t\t\t\t\t\t\t\t\t||");
        System.out.println("||\t\t%@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ \t\t\t\t\t\t\t\t\t||");
        System.out.println("||\t\t@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ \t\t\t\t\t\t\t\t\t\t||");
        System.out.println("||\t\t@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ :+#@@@@@@@ \t\t\t\t\t\t\t\t\t\t||");
        System.out.println("||\t\t*@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@*   -+%@# \t\t\t\t\t\t\t\t\t\t\t||");
        System.out.println("||\t\t =#@@@@@@@@@@@@@@@@@@@@@@@@@@#= \t\t\t\t\t\t\t\t\t\t\t\t\t\t||");
        System.out.println("||\t\t  .%@@@++@@@%. \t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t||");
        System.out.println("||\t\t =@@@%.	 .%@@@= \t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t||");
        System.out.println("||\t\t =%%=	   =%%= \t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t||");
        System.out.println("||\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t||");
        System.out.println("||\t ___ _____________________ ________ _____________________ \t\t\t\t\t\t\t\t\t||");
        System.out.println("||\t/ _ \\/_   __/  /   /    / ___/  _/ \\/ /  __/  |  / / _| \t\t\t\t\t\t\t\t\t||");
        System.out.println("||     /  ,_/  / /_\\ \\	  / /___ //	 /  _//  /\\_/ / __| \t\t\t\t\t\t\t\t\t\t||");
      System.out.println("||    /_ /\\_\\ /_/ /___/	  \\___/___/_/\\_/____/ _/  /_/_/|_| \t\t\t\t\t\t\t\t||");
        System.out.println("||\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t||");
        System.out.println("=================================================================================");

		
		System.out.println("                                                                                                                       ");
        System.out.println("                                                                                                                       ");
        System.out.println("                                                                                                                       ");

		System.out.print("Enter Date: ");
		String date=input.next();
		
		System.out.print("Location: ");
		String loca=input.next();
		
		System.out.println("                                    _           _ _      _    _        ___   _ _");
System.out.println("                                   /_\\__ ______(_) |__ _| |__| |___   |   __(_) |_ __ ___");
System.out.println("                                  / _ \\ \\// _' | | / _' |'__  \\/ _ )  | _|| | | '  \\(_-<");
System.out.println("                                 /_/ \\_\\_/\\__,_|_|_\\__,_|_._/_\\___| |_| |_|_|_|_|_/__");
System.out.println("                                                                                     ");
System.out.println("                                                                                     ");
System.out.println("                            =================================================================");

		
		System.out.println("                                                                                                                       ");
        System.out.println("                                                                                                                       ");
        System.out.println("                                                                                                                       ");

		System.out.println("             1) Movie 1  -  Hall 1                                                 2) Movie 2  -  Hall 2               ");
		System.out.println("             3) Movie 3  -  Hall 3                                                 4) Movie 4  -  Hall 4               ");
		System.out.println("                                                                                                                       ");
        System.out.println("                                                                                                                       ");
        System.out.println("                                                                                                                       ");
		System.out.print("Enter Movie Number: ");
		int mvnum=input.nextInt();
		
		System.out.println("                                      ________                                                                                 ");
		System.out.println("                                     |__    __|_                                                                                  ");
		System.out.println("                                        |  |  (_)_ __ ___  ___                                                                        ");
		System.out.println("                                        |  |  | | '_ ' _ \\/ _ \\                                                                      ");
		System.out.println("                                        |  |  | | | | | | | __/                                                                 ");
		System.out.println("                                        |__|  |_|_| |_| |_|\\___|                                                                          ");
		System.out.println("                                                                                                                       ");
        System.out.println("                                                                                                                       ");
        System.out.println("                                                                                                                       ");
		System.out.println("                     ===================================================================                        ");
		System.out.println("                                                                                                                       ");
        System.out.println("                                                                                                                       ");
        System.out.println("                                                                                                                       ");
        System.out.println("                                                       1) 9.00 A.M                                                     ");
        System.out.println("                                                       2) 2.00 P.M                                                     ");
        System.out.println("                                                       3) 7.00 P.M                                                     ");
        System.out.println("                                                                                                                       ");
        System.out.println("                                                                                                                       ");
        System.out.println("                                                                                                                       ");
        System.out.print("Enter Time: ");
        String time=input.next();
        
        System.out.println(" 				      _____           _                              										");
        System.out.println("				     / ____|         | |                            										");
        System.out.println("				     | |    _   _ ___| |_ ___  _ __ ___   ___ _ __  										");
        System.out.println("				     | |   | | | / __| __/ _ \\| '_ ` _ \\ / _ \\ '__| 									");
        System.out.println("				     | |___| |_| \\__ \\ || (_) | | | | | |  __/ |    									");
        System.out.println("				     \\_____\\__,_|___/\\__\\___/|_| |_| |_|\\___|_|   									");
        System.out.println("																													    ");
        System.out.println("																												        ");
        System.out.println("																												        ");
        System.out.println("                      ====================================================================                          ");
        System.out.println("                                                                                                                        ");
        System.out.println("                                                                                                                        ");
        System.out.println("                                                                                                                        ");
        
        System.out.print("Name : ");
        String name=input.next();
        
        System.out.print("Phone Number : ");
        int num=input.nextInt();
        
        System.out.print("Child or Parent : ");
        String corp=input.next();
        
        System.out.print("Number of Tickets : ");
        int numti=input.nextInt();
        
        double total =numti*90;
        
        double taxPercentage = 6.0;
        double tax=(total * taxPercentage)/100;
        
        
        System.out.println("+=========================================================================================================================+");
System.out.println("||                                          ___ _____________________ ________ _____________________                     ||");
System.out.println("||                                         / _ \\/_   __/  / __/    / ___/  _/ \\/ /  __/  |  / / _|                       ||");
System.out.println("||                                        /  ,_/  / /   _\\ \\       / /___ //_   /  _//  /\\_/ / __|                       ||");
System.out.println("||                                       /_ /\\_\\ /_/  /___/       \\___/___/_/\\_/____/ _/  /_/_/|_|                       ||");
System.out.println("||                                                                                                                       ||");
System.out.println("||Date : " + date + "                                                                                  Location : " + loca + "            ||");
System.out.println("||                                                                                                                       ||");
System.out.println("||-----------------------------------------------------------------------------------------------------------------------||");
System.out.println("||                                                                                                                       ||");
System.out.println("||                                                                                                                       ||");
System.out.println("||   Name               :  " + name + "                                                                                          ||");
System.out.println("||                                                                                                                       ||");
System.out.println("||                                                                                                                       ||");
System.out.println("||   Phone Number       :  " + num + "                                                                                          ||");
System.out.println("||                                                                                                                       ||");
System.out.println("||                                                                                                                       ||");
System.out.println("||   Tickets            :  " + numti + "                                                                                             ||");
System.out.println("||                                                                                                                       ||");
System.out.println("||                                                                                                                       ||");
System.out.println("||   Type               :  " + corp + "                                                                                          ||");
System.out.println("||                                                                                                                       ||");
System.out.println("||                                                                                                                       ||");
System.out.println("||   Time               :  " + time + "                                                                                             ||");
System.out.println("||                                                                                                                       ||");
System.out.println("||                                                                                                                       ||");
System.out.println("||   Hall               :  " + mvnum + "                                                                                             ||");
System.out.println("||                                                                                                                       ||");
System.out.println("||                                                                                                                       ||");
System.out.println("||   Tax                :  " + tax + "                                                                                          ||");
System.out.println("||                                                                                                                       ||");
System.out.println("||                                                                                                                       ||");
System.out.println("||                                                                                                Total : " + (total + tax) + "          ||");
System.out.println("||                                                                                                                       ||");
System.out.println("||                                                                                                                       ||");
System.out.println("||                                                                                                                       ||");
System.out.println("+=========================================================================================================================+");
		
		
	}
}

