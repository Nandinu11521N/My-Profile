import java.util.*;
class Burger{
	public static Scanner input=new Scanner(System.in);
		
		public static void startSystem(){
				A :while(true){	
				System.out.println("\n\n\n\n");	
				System.out.println("		  ||=================================================================================================||\n\n");
				System.out.println("			.__  ___ ___                                     __________                                  ");                  
				System.out.println("			|__|/   |   \\ __ __  ____    ___________ ___.__. \\______   \\__ _________  ____   ___________ ");  
				System.out.println("			|  /    ~    \\  |  \\/    \\  / ___\\_  __ <   |  |  |    |  _/  |  \\_  __ \\/ ___\\_/ __ \\_  __ \\"); 
				System.out.println("			|  \\    Y    /  |  /   |  \\/ /_/  >  | \\/\\___  |  |    |   \\  |  /|  | \\/ /_/  >  ___/|  | \\/");
				System.out.println("			|__|\\___|_  /|____/|___|  /\\___  /|__|   / ____|  |______  /____/ |__|  \\___  / \\___  >__|   ");
				System.out.println("			          \\/            \\//_____/        \\/              \\/            /_____/      \\/        \n\n\n");
				System.out.println("		  ||================================================================================================||\n\n\n\n    ");
				System.out.printf("                                %-21s                          %-21s\n\n\n\n\n","[1] PLACE ORDER","[2] SEARCH BEST CUSTOMER");				//[1] Place Order									[2] Search Best Customer			\n\n\n");
				System.out.printf("                                %-21s                          %-21s\n\n\n\n\n","[3] SEARCH ORDER","[4] SEARCH CUSTOMER");
				System.out.printf("                                %-21s                          %-21s\n\n\n\n\n","[5] VIEW ORDERS","[6] UPDATE ORDER DETAILS");
				System.out.printf("                                %-21s                                                                \n\n\n\n\n","[7] EXIT");
				
				systemController();
			}
		}
		
		public static void systemController(){
				System.out.print("Enter an option to continue -> ");
				char num = input.next().charAt(0);
				System.out.print("\033[H\033[2J");
				System.out.flush();
				System.out.println("\n\n\n");
				
				switch(num){
					case '1': placeOrder();
					        break;
					case '2': bestCustomer();
					        break;
					case '3': searchOrder();
					        break;
					case '4': searchCustomer();
					        break;
					case '5': viewOrders();
					        break;
					case '6': updateOrder();
					        break;
					case '7': System.out.println("\n\n\n\n"); 
							  System.out.println("			___________.__                   __     _____.___.              ._. _________                           _____                .__                        ");   
							  System.out.println("			\\__    ___/|  |__ _____    ____ |  | __ \\__  |   | ____  __ __  | | \\_   ___ \\  ____   _____   ____    /  _  \\    _________  |__| ____                  "); 
							  System.out.println("			   |    |   |  |  \\__  \\  /    \\|  |/ /  /   |   |/  _ \\|  |  \\ | | /    \\  \\/ /  _ \\ /     \\_/ __ \\  /  /_\\  \\  / ___\\__  \\ |  |/    \\                 ");
							  System.out.println("			   |    |   |   Y  \\/ __ \\|   |  \\   <   \\____   (  <_> )  |  /  \\| \\     \\___(  <_> )  Y Y  \\ ___/  /    |    \\/ /_/  > __ \\|  |   |  \\                ");  
							  System.out.println("			   |____|   |___|  (____  /___|  /__|_\\  / ______|\\____/|____/   __  \\______  /\\____/|__|_|  /\\___ > \\____|__  /\\___  (____  /__|___|  / /\\  /\\  /\\  /\\ ");  
							  System.out.println("			                \\/     \\/     \\/     \\/  \\/                      \\/         \\/             \\/     \\/          \\//_____/    \\/        \\/  \\/  \\/  \\/  \\/ \n\n\n ");
				              System.exit(0);
				   default :invalidController();
			   }
		   }
		   
	   public static void placeOrder(){
		 System.out.println("			||=====================================================================||\n\n");
		 System.out.println("			__________.__                        ________            .___            ");   
		 System.out.println("			\\______   \\  | _____    ____  ____   \\_____  \\_______  __| _/___________ "); 
		 System.out.println("			 |     ___/  | \\__  \\ _/ ___\\/ __ \\   /   |   \\_  __ \\/ __ |/ __ \\_  __ \\");
		 System.out.println("			 |    |   |  |__/ __ \\  \\__\\  ___/  /    |    \\  | \\/ /_/ \\  ___/|  | \\/");  
		 System.out.println("			 |____|   |____(____  /\\___  >___  > \\_______  /__|  \\____ |\\___  >__|   ");  
		 System.out.println("			                    \\/     \\/    \\/          \\/           \\/    \\/       \n\n\n ");
		 System.out.println("			||=====================================================================||\n\n\n\n\n\n");
		 String orderId = getLastOrderID();
		 System.out.println("						Order ID: " + orderId + "\n\n\n\n\n");
		 String number = getNumber();
		 String duplicateName = null;
		 String name = null;
		 for (int i = 0; i < numbers.length; i++){
			 if (number.equalsIgnoreCase(numbers[i])){
				  duplicateName = names[i];
				  name = duplicateName;
			 if (name != null){
			   System.out.println("\n\n\n\n\n\n\n    Enter Customer Name :- "+name);   
		   }break;
	   }
   }
                 if(name == null){
				 System.out.println("\n\n\n\n\n\n");
				 name = getName();
			 }
				 System.out.println("\n\n\n\n\n\n");
				 int burgerQuantity = getBurger();
				 System.out.println("\n\n\n\n\n\n");
				 double totalValue = getTotal(burgerQuantity);
				 System.out.println("    Total Value :- "+totalValue);
				 System.out.println("\n\n\n\n");
				 do{
				 System.out.print("			Are You Confirm Order (y/n) :- ");
				 String yesOrNo = input.next();
				 if(yesOrNo.equals("y")){ 
					 clearScreen();
					 extendAllArrays(); 
					 orderIDs[orderIDs.length-1] = orderId;
					 numbers[orderIDs.length-1] = number;
					 names[orderIDs.length-1] = name;
					 burgers[orderIDs.length-1] = burger;
					 totals[orderIDs.length-1] = totalValue;
					 orderStatusArray[orderIDs.length-1] = PREPARING;
					 
					 System.out.println("						Your order has been entered into the system successfully...\n\n\n");
					 System.out.println("\n\n\n\n\n");
					 System.out.print("Do You Want To Place Another Order (y/n) :- ");
					 String yesOrNo2 = input.next();
					 if (yesOrNo2.equals("y")){
						 System.out.println();
						placeOrder();
					}else if(yesOrNo2.equals("n")){	
						System.out.println();
						startSystem();
					}else{
						clearScreen();
						System.out.println("Invalid input. Please enter 'y' for Yes or 'n' for No.");
						System.out.println("\n\n\n");
					}
					
					}else if (yesOrNo.equals("n")){
							clearScreen();
							placeOrder(); 
					}else{
							clearScreen();
							System.out.println("Invalid input. Please enter 'y' for Yes or 'n' for No.");
							System.out.println("\n\n\n");
						}
					}while(true);
				}
	
				private static String[] numbers = new String[0];
				private static String[] names = new String[0];
				private static String[] orderIDs = new String[0];
				private static int[] burgers = new int[0];
				private static int[] orderStatusArray =new int[0];
				private static double[] totals = new double[0];
				
				public static final int PREPARING = 0;
				public static final int DELIVERED = 1;
				public static final int CANCEL = 2;
		
				public static int burger;
				public static double total;
    
				public static String getLastOrderID(){
					if (orderIDs.length>0){
						String lastId = orderIDs[orderIDs.length-1];
						String[] ar = lastId.split("[B]");
						int num = Integer.parseInt(ar[1]);
						num++;
						return String.format("B%04d",num);
					}
					return "B0001";
				}
				
				public static String getNumber(){
					while(true){
						System.out.print("    Enter Customer ID (Phone Number) :- ");
						String num=input.next();	
						if(num.startsWith("0") && num.length() == 10){
							return num;
						}else{
							System.out.println("\n\n\n\n	Invalid phone number. Please enter your 10-digit number starting with '0'.\n\n\n\n");
						}
					}
				}
		
				public static String getName(){
					System.out.print("    Enter Customer Name :- ");
					String name=input.next();
					return name;
				}
		
				public static int getBurger(){
					System.out.print("    Enter Burger Quantity :- ");
					burger = input.nextInt();
					return burger;
				}
		
				public static double getTotal(int burgerQuantity){
					double BURGERPRICE=500;
					double total= BURGERPRICE * burgerQuantity;
					return total;
				}
			
				public static void bestCustomer(){
					 System.out.println("			||=====================================================================================================================================||\n\n");					
					 System.out.println("			  _________                           .__      __________                 __    _________                 __                               ");   
					 System.out.println("			 /   _____/ ____ _____ _______  ____  |  |__   \\______   \\ ____   _______/  |_  \\_   ___ \\ __ __  _______/  |_  ____   _____   ___________ "); 
					 System.out.println("			 \\_____  \\_/ __ \\__  \\ _  __ \\_/ ___\\ |  |  \\   |    |  _// __ \\ /  ___/\\   __\\ /    \\  \\/|  |  \\/  ___/\\   __\\/  _ \\ /     \\_/ __ \\_  __ \\");
					 System.out.println("			 /        \\  ___/ / __ \\|  | \\/\\  \\___|   Y  \\  |    |   \\  ___/ \\___ \\  |  |   \\     \\___|  |  /\\___ \\  |  | (  <_> )  Y Y  \\  ___/|  | \\/");  
					 System.out.println("			/_______  /\\___  >____  /__|    \\___  >___|  /  |______  /\\___  >____  > |__|    \\______  /____//____  > |__|  \\____/|__|_|  /\\___  >__|   ");  
					 System.out.println("			        \\/     \\/     \\/            \\/     \\/          \\/     \\/     \\/                 \\/           \\/                    \\/     \\/       \n\n\n ");
					 System.out.println("			||=====================================================================================================================================||\n\n\n\n\n\n");

                     System.out.println("	|----------------------------------------------------------------------------------------------------|\n");
					 System.out.println("		Customer ID				Name				Total		\n");
					 System.out.println("	|----------------------------------------------------------------------------------------------------|");
					 System.out.println("	|----------------------------------------------------------------------------------------------------|\n");
					 
					 
					int uniqueCount = 0;
					String[] uniqueNames = new String[names.length];
					String[] uniqueNumbers = new String[numbers.length];
					double[] aggregatedTotals = new double[names.length];

					for (int i = 0; i < names.length; i++) {
						boolean isUnique = true;

						for (int j = 0; j < uniqueCount; j++) {
							if (uniqueNames[j] != null && uniqueNames[j].equals(names[i])) {
								isUnique = false;
								break;
							}
						}
						if (isUnique) {
							if(orderStatusArray[i]==0 || orderStatusArray[i]==1){
							uniqueNames[uniqueCount] = names[i];
							uniqueNumbers[uniqueCount] = numbers[i];
							uniqueCount++;
						}
					}
						for (int k = 0; k < uniqueCount; k++) {
							if (uniqueNames[k] != null && uniqueNames[k].equals(names[i])){
								if(orderStatusArray[i]==0 || orderStatusArray[i]==1){
								aggregatedTotals[k] += totals[i];
								break;
							}
						}
					}
				}
					for (int i = 0; i < uniqueCount - 1; i++) {
						for (int j = 0; j < uniqueCount - i - 1; j++) {
							if (aggregatedTotals[j] < aggregatedTotals[j + 1]) {
								double tempTotal = aggregatedTotals[j];
								aggregatedTotals[j] = aggregatedTotals[j + 1];
								aggregatedTotals[j + 1] = tempTotal;

								String tempName = uniqueNames[j];
								uniqueNames[j] = uniqueNames[j + 1];
								uniqueNames[j + 1] = tempName;

								String tempNumber = uniqueNumbers[j];
								uniqueNumbers[j] = uniqueNumbers[j + 1];
								uniqueNumbers[j + 1] = tempNumber;
							}
						}
					}
					for (int i = 0; i < uniqueCount; i++) {
						System.out.printf("                %-35s %-35s %-20.2f%n", uniqueNumbers[i], uniqueNames[i], aggregatedTotals[i]);
						System.out.println("        |----------------------------------------------------------------------------------------------------|\n");
					}
					
					while(true){
							System.out.print("			Do You Want To Go Back To Main Menu (y/n) ? ");
							String yesOrNo = input.next();
							if(yesOrNo.equals("y")){ 
								clearScreen();
								startSystem();
								System.out.println("\n\n\n\n\n");
							}else if (yesOrNo.equals("n")) {
								clearScreen();
								bestCustomer(); 
								System.out.println("\n\n\n\n\n");
							}else{
								clearScreen();
								System.out.println("Invalid input. Please enter 'y' for Yes or 'n' for No.");
								System.out.println("\n\n\n");
							}
						}
					}
				
				 
				public static void searchOrder(){
					System.out.println("			||==========================================================================================||\n\n");
					System.out.println("			   _________                           .__      ________            .___            ");   
					System.out.println("			  /   _____/ ____ _____ _______   ____ |  |__   \\_____  \\_______  __| _/___________ "); 
					System.out.println("			  \\_____  \\_/ __ \\__  \\_  __ \\_/ ___\\|  |  \\   /   |   \\_  __ \\/ __ |/ __ \\_  __ \\");
					System.out.println("			  /        \\  ___/ / __ \\|  | \\/\\  \\___|   Y  \\ /    |    \\  | \\/ /_/ \\  ___/|  | \\/");  
					System.out.println("			/_______  /\\___  >____  /__|    \\___  >___|  / \\_______  /__|  \\____ |\\___  >__|   ");  
					System.out.println("			        \\/     \\/     \\/            \\/     \\/          \\/           \\/    \\/       \n\n\n ");
					System.out.println("			||==========================================================================================||\n\n\n\n\n\n");
					System.out.print("Enter Order ID - ");
					String sOrder = input.next();
				    int index=-1;
					for (int i = 0; i < orderIDs.length; i++){
						if(sOrder.equalsIgnoreCase(orderIDs[i])){
							
							index=i;
							break;
						}
					}
					if(index != -1){
					    String statusString;
					    String num=numbers[index];
						String name=names[index];
						int burger=burgers[index];
						double total=totals[index];
						if(orderStatusArray[index]==PREPARING){
							statusString="PREPARING";
						}else if(orderStatusArray[index]==DELIVERED){
							statusString="DELIVERED";
						}else if(orderStatusArray[index]==CANCEL){
							statusString="CANCELLED";
						}else statusString="INVALID";
					
						System.out.println("\n\n");
						System.out.println("            	       |--------------------------------------------------------------------------------------------------------------------------------------------------------|\n");
						System.out.printf("			%-18s           %-18s          %-18s           %-10s            %-18s            %-18s       \n","Order ID","Customer ID","Name","Quantity","Order Value","Order Status\n");
						System.out.println("            	       |--------------------------------------------------------------------------------------------------------------------------------------------------------|\n\n");
						System.out.printf("			%-18s           %-18s          %-18s           %-10s            %-18s            %-18s       \n",sOrder,num,name,burger,total,statusString);
						System.out.println("            	       |--------------------------------------------------------------------------------------------------------------------------------------------------------|\n\n\n");
						while(true){
							System.out.print("Do You Want To Exit (y/n) :- ");
							String yesOrNo = input.next();
							if(yesOrNo.equals("y")){ 
								clearScreen();
								startSystem();
								System.out.println("\n\n\n\n\n");
							}else if (yesOrNo.equals("n")) {
								clearScreen();
								searchOrder(); 
							}else{
								clearScreen();
								System.out.println("Invalid input. Please enter 'y' for Yes or 'n' for No.");
								System.out.println("\n\n\n");
							}
						} 
					}else{
						while(true){
							System.out.print("\n\n\nInvalid Order ID.....Do You Want To Enter Again ? (y/n) :- ");
							String yesOrNo = input.next();
							if(yesOrNo.equals("y")){ 
								clearScreen();
								searchOrder();
								System.out.println("\n\n\n\n\n");
							}else if (yesOrNo.equals("n")) {
								clearScreen();
								startSystem(); 
							}else{
								clearScreen();
								System.out.println("Invalid input. Please enter 'y' for Yes or 'n' for No.");
								System.out.println("\n\n\n");
							}
						}
					}
				}
				
			public static void searchCustomer(){
				 System.out.println("			||===============================================================================================================||\n\n");
				 System.out.println("			   _________                           .__      _________                 __                               ");   
				 System.out.println("			  /   _____/ ____ _____ _______   ____ |  |__   \\_   ___ \\ __ __  _______/  |_  ____   _____   ___________ "); 
				 System.out.println("			  \\_____  \\_/ __ \\__  \\_  __   \\_/ ___\\|  |  \\  /    \\  \\/|  |  \\/  ___/\\   __\\/  _ \\ /     \\_/ __ \\_  __ \\");
				 System.out.println("			  /        \\  ___/ / __ \\|  | \\/\\  \\___|   Y  \\ \\     \\___|  |  /\\___ \\  |  | (  <_> )  Y Y  \\  ___/|  | \\/");  
				 System.out.println("			 /_______  /\\___  >____  /__|    \\___  >___|  /  \\______  /____//____  > |__|  \\____/|__|_|  /\\___  >__|   ");  
				 System.out.println("			         \\/     \\/     \\/            \\/     \\/          \\/           \\/                    \\/     \\/       \n\n\n ");
				 System.out.println("			||===============================================================================================================||\n\n\n\n\n\n");
				 
				 while(true){ 
				 System.out.print("			Enter Customer ID :- ");
				 String searchNumber = input.next();
				 int index=-1;
				 
				 String tOrder;
				 int tQuantity;
				 double tValue;
				 String tname="";
				 int tIndex=-1;
				 for (int i = 0; i <numbers.length ; i++){
					if(searchNumber.startsWith("0") && searchNumber.length() == 10  && searchNumber.equalsIgnoreCase(numbers[i])){
						index=0;
						tIndex=i;
						tname=names[i];	
						i=numbers.length+1;	
							 System.out.println("\n\n\n			Customer ID :- "+searchNumber+"\n\n");
							 System.out.println("			Name        :- "+tname+"\n\n\n");
							 System.out.println("		      ||======================||\n");		 
							 System.out.println("			Customer Order Details\n");
							 System.out.println("		      ||======================||\n\n\n");	 
							 System.out.println("|-----------------------------------------------------------------------------------------------|");
							 System.out.println(" Order ID				 Order Quantity				Total Value");
							 System.out.println("|-----------------------------------------------------------------------------------------------|\n\n");
						 }
					 }
						 for (int i=0; i <numbers.length ; i++){
							if(searchNumber.equalsIgnoreCase(numbers[i])){
								 tOrder=orderIDs[i];
								 tQuantity=burgers[i];
								 tValue=totals[i];
							 System.out.println("  "+tOrder+"						"+tQuantity+"				"+tValue+"\n");
						 }
					 }   
					 if(index!=-1){
					 System.out.println("|-----------------------------------------------------------------------------------------------|\n\n");
					 System.out.print("		Do You Want To Search Another Customer Details (y/n) ?");
					 String yesOrNo = input.next();
						if(yesOrNo.equals("y")){ 
							clearScreen();
							searchCustomer();
							System.out.println("\n\n\n\n\n");
						}else if (yesOrNo.equals("n")) {
							clearScreen();
							startSystem(); 
						}else{
							clearScreen();
							System.out.println("Invalid input. Please enter 'y' for Yes or 'n' for No.");
							System.out.println("\n\n\n");
						}
					}else if(index==-1){
						System.out.println("\n\n\n		This Customer ID Is Not Added Yet OR Invalid Number...........\n\n\n");
						while(true){
						System.out.print("		Do You Want To Search Another Customer Details (y/n) ?");
						String yesOrNo2 = input.next();
						if(yesOrNo2.equals("y")){ 
							clearScreen();
							searchCustomer();
							System.out.println("\n\n\n\n\n");
						}else if (yesOrNo2.equals("n")) {
							clearScreen();
							startSystem(); 
						}else{
							clearScreen();
							System.out.println("Invalid input. Please enter 'y' for Yes or 'n' for No.");
							System.out.println("\n\n\n");
						}
					}
				}
			}
		}					
				 public static void viewOrders(){
					 System.out.println("			||==========================================================================================||\n\n");
					 System.out.println("				   ____   ____.__                ________            .___                   ");   
					 System.out.println("				  \\   \\ /   /|__| ______  _  __ \\_____  \\_______  __| _/___________  ______"); 
					 System.out.println("				   \\   Y   / |  |/ __ \\ \\/ \\/ /  /   |   \\_  __ \\/ __ |/ __ \\_  __ \\/  ___/");
					 System.out.println("				    \\     /  |  \\  ___/\\     /  /    |    \\  | \\/ /_/ \\  ___/|  | \\/\\___ \\ ");  
					 System.out.println("				     \\___/   |__|\\___  >\\/\\_/   \\_______  /__|  \\____ |\\___  >__|  /____  >");  
					 System.out.println("				                       \\/                 \\/           \\/    \\/           \\/ \n\n\n ");
					 System.out.println("			||==========================================================================================||\n\n\n\n\n\n");
					 System.out.println("			[1] Delivered Order\n\n");
					 System.out.println("			[2] Preparing Order\n\n");
					 System.out.println("			[3] Cancel Order\n\n");
					 System.out.print("			Enter an option to Continue :- ");
					 int num = input.nextInt();
					 if(num==1){
						 int index=-1;
						 System.out.println("					||---------------------------------------------------------------------------------------------------------------||");
						 System.out.println("                                							 Delivered Orders                                                     ");
						 System.out.println("					||---------------------------------------------------------------------------------------------------------------||\n\n\n\n");
						 System.out.println("            	       |--------------------------------------------------------------------------------------------------------------------------------------------------------|\n");
						 System.out.printf("			%-18s           %-18s          %-18s           %-10s            %-18s            \n","Order ID","Customer ID","Name","Quantity","Order Value\n");

						for (int i = 0; i < orderStatusArray.length; i++){
							if(orderStatusArray[i]==1){
								index=i;
								String numb=numbers[index];
								String order=orderIDs[index];
								String name=names[index];
								int burger=burgers[index];
								double total=totals[index];
				
								System.out.println("            	       |--------------------------------------------------------------------------------------------------------------------------------------------------------|\n\n");
								System.out.printf("			%-18s           %-18s          %-18s           %-10s            %-18s            \n",order,numb,name,burger,total);
								System.out.println("            	       |--------------------------------------------------------------------------------------------------------------------------------------------------------|\n\n");
							}
						}
					}else if(num==2){
						int index=-1; 
						System.out.println("					||--------------------------------------------------------------------------------------------------------------||");
						System.out.println("                                							 Preparing Orders                                                     ");
						System.out.println("					||--------------------------------------------------------------------------------------------------------------||\n\n\n\n");
						System.out.println("            	       |--------------------------------------------------------------------------------------------------------------------------------------------------------|\n");
						System.out.printf("			%-18s           %-18s          %-18s           %-10s            %-18s            \n","Order ID","Customer ID","Name","Quantity","Order Value\n");

				
				 
					for (int i = 0; i < orderStatusArray.length; i++){
						if(orderStatusArray[i]==0){
							index=i;
							String numb=numbers[index];
							String order=orderIDs[index];
							String name=names[index];
							int burger=burgers[index];
							double total=totals[index];
							
							System.out.println("            	       |--------------------------------------------------------------------------------------------------------------------------------------------------------|\n\n");
							System.out.printf("			%-18s           %-18s          %-18s           %-10s            %-18s            \n",order,numb,name,burger,total);
							System.out.println("            	       |--------------------------------------------------------------------------------------------------------------------------------------------------------|\n\n");
						}
					}
				}else if(num==3){
					int index=-1;	 
					System.out.println("					||---------------------------------------------------------------------------------------------------------------||");
					System.out.println("                                							 Cancel Orders                                                     ");
					System.out.println("					||---------------------------------------------------------------------------------------------------------------||\n\n\n\n");
					System.out.println("            	       |--------------------------------------------------------------------------------------------------------------------------------------------------------|\n");
					System.out.printf("			%-18s           %-18s          %-18s           %-10s            %-18s            \n","Order ID","Customer ID","Name","Quantity","Order Value\n");

					for (int i = 0; i < orderStatusArray.length; i++){
						if(orderStatusArray[i]==2){
							index=i;
							String numb=numbers[index];
							String order=orderIDs[index];
							String name=names[index];
							int burger=burgers[index];
							double total=totals[index];
								
							System.out.println("            	       |--------------------------------------------------------------------------------------------------------------------------------------------------------|\n\n");
							System.out.printf("			%-18s           %-18s          %-18s           %-10s            %-18s            \n",order,numb,name,burger,total);
							System.out.println("            	       |--------------------------------------------------------------------------------------------------------------------------------------------------------|\n\n");
						}
					}
				}else{
					while(true){
						System.out.print("\n\n\n			Invalid Input.....Do You Want To Exit ? (y/n) :- ");
						String yesOrNo = input.next();
						if(yesOrNo.equals("y")){
							clearScreen();
							viewOrders();
							System.out.println("\n\n\n\n\n");
						}else if(yesOrNo.equals("n")){
							clearScreen();
							startSystem();
						}else{
							clearScreen();
							System.out.println("			Invalid input. Please enter 'y' for Yes or 'n' for No.");
							System.out.println("\n\n\n");
						}
					}
				}
				while(true){
					System.out.println("            	        --------------------------------------------------------------------------------------------------------------------------------------------------------");
					System.out.println("            	                                ---------------------------------------------------------------------------------------------\n\n");
					System.out.print("			Do You Want To Exit ? (y/n) :- ");
					String yesOrNo = input.next();
					if(yesOrNo.equals("y")){ 
						clearScreen();
						startSystem();
						System.out.println("\n\n\n\n\n");
					}else if(yesOrNo.equals("n")){
						clearScreen();
						viewOrders(); 
					}else{
						clearScreen();
						System.out.println("			Invalid input. Please enter 'y' for Yes or 'n' for No.");
						System.out.println("\n\n\n");
					}
				}
			}
				
			public static void updateOrder(){
				System.out.println("			||==========================================================================================||\n\n");
				System.out.println("			   ____ ___            .___       __           ________            .___            ");   
				System.out.println("			  |    |   \\______   __| _/____ _/  |_  ____   \\_____  \\_______  __| _/___________ "); 
				System.out.println("			  |    |   /\\____ \\ / __ |\\__  \\   __\\/ __ \\   /   |   \\_  __ \\/ __ |/ __ \\_  __ \\");
				System.out.println("			  |    |  / |  |_> > /_/ | / __ \\|  | \\  ___/  /    |    \\  | \\/ /_/ \\  ___/|  | \\/");  
				System.out.println("			  |______/  |   __/\\____ |(____  /__|  \\___  > \\_______  /__|  \\____ |\\_ __  >__|  ");  
				System.out.println("			              |__|        \\/     \\/          \\/          \\/           \\/    \\/       \n\n\n ");
				System.out.println("			||==========================================================================================||\n\n\n\n\n\n");
				System.out.print("----------------------------\n");
				System.out.print("Enter Order ID :- ");
				String order = input.next();
				int index=-1;
				for (int i = 0; i < orderIDs.length; i++){
					if(order.equalsIgnoreCase(orderIDs[i])){
						index=i;
						break;
					}
				}
				if(index != -1){
					String statusString;
					if(orderStatusArray[index]==PREPARING){
						statusString="PREPARING";
					}else if(orderStatusArray[index]==DELIVERED){
						statusString="DELIVERED";
					}else if(orderStatusArray[index]==CANCEL){
						statusString="CANCELLED";
					}else statusString="INVALID"; 
						
					if(index != -1){
						String num=numbers[index];
						String name=names[index];
						int burger=burgers[index];
						double total=totals[index];
							
						if(orderStatusArray[index]==PREPARING){
							System.out.println("The order is being prepared.");
						}else if(orderStatusArray[index]==DELIVERED){
							System.out.println("The order has been delivered.");
						}else if(orderStatusArray[index]==CANCEL){
							System.out.println("The order has been cancelled.");
						}else System.out.println("Invalid status.");
					
						System.out.println("Order ID :- "+order);
						System.out.println("----------------------------\n\n");
						System.out.println("Customer ID :- "+num+"\n\n");
						System.out.println("Name :- "+name+"\n\n");
						System.out.println("Quantity :- "+burger+"\n\n");
						System.out.println("Order Value :- "+total+"\n\n");
						System.out.println("Order Status :- "+statusString+"\n\n");
				
						if(orderStatusArray[index]==DELIVERED || orderStatusArray[index]==CANCEL){
							System.out.println("			Sorry.....Order Can't Be Update..........Already DELIVERED Or CANCELLED.");
						}else{
							System.out.println("			What Do You Want To Update ? \n\n");
							System.out.println("		[01]Quantity\n\n\n");
							System.out.println("		[02]Status\n\n\n");
							System.out.print("			Enter Your Option :- ");
							int option = input.nextInt();
				
							if(option==1){
								System.out.println("			Quantity Update");
								System.out.println("			================\n\n\n");
								System.out.println("			Order ID :- "+order+"\n\n");
								System.out.println("			Customer ID :- "+num+"\n\n");
								System.out.println("			Name :- "+name+"\n\n");
								System.out.print("			Enter Your Quantity Update Value :- ");
								int newquantity = input.nextInt();
								burger=newquantity;
								burgers[index]=burger;
								System.out.println("			Update Order Quantity Successfully......\n\n\n");
								System.out.println("			New Order Quantity :- "+newquantity+"\n\n");
								totals[index]=burgers[index]*500;
								System.out.println("			New Order Value :- "+totals[index]+"\n\n");
					
								while(true){
									System.out.print("			Do You Want To Update Another Order Details ? (y/n) ");
									String yesOrNo = input.next();
									if(yesOrNo.equals("y")){ 
										clearScreen();
										updateOrder();
										System.out.println("\n\n\n\n\n");
									}else if(yesOrNo.equals("n")){
										clearScreen();
										startSystem(); 
									}else{
										clearScreen();
										System.out.println("Invalid input...... Please enter 'y' for Yes or 'n' for No.");
										System.out.println("\n\n\n");
									}
								}
							}if(option==2){
								System.out.println("			Status Update");
								System.out.println("			================\n\n\n");
								System.out.println("			Order ID :- "+order+"\n\n");
								System.out.println("			Customer ID :- "+num+"\n\n");
								System.out.println("			Name :- "+name+"\n\n\n\n");
								System.out.println("			[0] Cancel\n");
								System.out.println("			[1] Preparing\n");
								System.out.println("			[2] Delivered\n\n");
			
								System.out.print("			Enter New Order Status :- ");
								char newStatus = input.next().charAt(0);	
								if(newStatus=='0'){
									orderStatusArray[index]=CANCEL;
								}else if(newStatus=='1'){
									orderStatusArray[index]=PREPARING;
								}else if(newStatus=='2'){
									orderStatusArray[index]=DELIVERED;
								}
								
								if(orderStatusArray[index]==PREPARING){
									statusString="PREPARING";
								}else if(orderStatusArray[index]==DELIVERED){
										statusString="DELIVERED";
								}else if(orderStatusArray[index]==CANCEL){
									statusString="CANCELLED";
								}
								System.out.println("\n\n			New Order Status :- "+statusString+"\n\n\n");
								
								while(true){
									System.out.print("			Do You Want To Update Another Order Details ? (y/n) ");
									String yesOrNo = input.next();
									if(yesOrNo.equals("y")){ 
										clearScreen();
										updateOrder();
										System.out.println("\n\n\n\n\n");
									}else if(yesOrNo.equals("n")){
										clearScreen();
										startSystem(); 
									}else{
										clearScreen();
										System.out.println("Invalid input. Please enter 'y' for Yes or 'n' for No.");
										System.out.println("\n\n\n");
									}
								}	
							}else{
								while(true){
									System.out.print("\n\n\n			Invalid Input.....Do You Want To Enter Again ? (y/n) :- ");
									String yesOrNo = input.next();
									if(yesOrNo.equals("y")){ 
										clearScreen();
										updateOrder();
										System.out.println("\n\n\n\n\n");
									}else if(yesOrNo.equals("n")){
										clearScreen();
										startSystem(); 
									}else{
									clearScreen();
									System.out.println("\n\n\n			Invalid input. Please enter 'y' for Yes or 'n' for No.");
									System.out.println("\n\n\n");
								}
							}
						}
					}
				}
			}else if(index ==-1){
				while(true){
					System.out.print("\n\n\n			Invalid Order ID.....Do You Want To Enter Again ? (y/n) :- ");
					String yesOrNo = input.next();
					if(yesOrNo.equals("y")){ 
						clearScreen();
						updateOrder();
						System.out.println("\n\n\n\n\n");
					}else if(yesOrNo.equals("n")){
						clearScreen();
						startSystem(); 
					}else{
					clearScreen();
					System.out.println("\n\n\n			Invalid input. Please enter 'y' for Yes or 'n' for No.");
					System.out.println("\n\n\n");
				}
			}
		}
	}
							
		public static void extendAllArrays(){
			String[] tempCustIds = new String[numbers.length+1];
			String[] tempOrderIds = new String[numbers.length+1];
			String[] tempNames = new String[numbers.length+1];
			int[] tempQtys = new int[numbers.length+1];
			int[] tempStatus = new int[numbers.length+1];
			double[] tempTotal = new double[numbers.length+1];
			
			for (int i = 0; i < numbers.length; i++){
				tempCustIds[i] = numbers[i];
				tempOrderIds[i] = orderIDs[i];
				tempNames[i] = names[i];
				tempQtys[i] = burgers[i];
				tempStatus[i] = orderStatusArray[i];
				tempTotal[i] = totals[i];
			}
			numbers = tempCustIds;
			orderIDs = tempOrderIds;
			names = tempNames;
			burgers = tempQtys;
			orderStatusArray = tempStatus;
			totals = tempTotal;
		}
			
		public static void clearScreen() {
			System.out.print("\033[H\033[2J");
			System.out.flush();
		}
				 
		public static void invalidController(){			   
		   System.out.println("\n\n\n\n				Invalid Input....Please Try Again......\n\n\n");
	   }
	   
		public static void main(String args[]){
			
			startSystem();		
		}
	}
