import java.util.*;
class Bank {	
		public static void system(){
				A :while(true){	
				System.out.println("\n\n\n\n");	
				System.out.println("			__________               __       _________               __                                  ");                  
				System.out.println("			\\______   \\_____   ____ |  | __  /   _____/__.__. _______/  |_  ____   _____                ");  
				System.out.println("			|    |  _/\\__  \\  /    \\|  |/ /  \\_____  <   |  |/  ___/\\   __\\/ __ \\ /     \\         "); 
				System.out.println("			|    |   \\ / __ \\|   |  \\    <   /        \\___  |\\___ \\  |  | \\  ___/|  Y Y  \\        ");
				System.out.println("			|______  /(____  /___|  /__|_ \\ /_______  / ____/____  > |__|  \\___  >__|_|  /              ");
				System.out.println("		    	    \\/      \\/     \\/     \\/         \\/\\/         \\/            \\/      \\/ \n\n\n");
				System.out.println("			==================================================================================\n\n\n\n    ");
				System.out.println("				[1] Deposit						[2] Loans                            \n\n\n               ");
				System.out.println("				[3] Tax 						[4] Share Market                     \n\n\n               ");
				System.out.println("				[5] Exit                                                             \n\n\n\n             ");
				
				systemController();
			}
		}
		
		public static void deposit(){
			     B :while(true){
			     System.out.println("				________                             .__  __           ");   
				 System.out.println("				\\______ \\   ____ ______   ____  _____|__|/  |_       "); 
				 System.out.println("				 |    |  \\_/ __ \\____ \\ /  _ \\/  ___/  \\   __\\   ");
				 System.out.println("				 |    `   \\  ___/|  |_> >  <_> )___ \\|  ||  |        ");  
				 System.out.println("				/_______  /\\___  >   __/ \\____/____  >__||__|        ");  
				 System.out.println("				        \\/     \\/|__|              \\/        \n\n\n ");
				 System.out.println("				===============================================\n\n\n\n");
				 System.out.println("				              [1] Saving Account               \n\n\n  ");
				 System.out.println("				              [2] Fixed Deposit               \n\n\n   ");
				 System.out.println("				              [3] Exit                        \n\n\n   ");
				 
				 depositController();
			 }
		 }
		 
		 public static void loans(){
			    C :while(true){	        
		        System.out.println("				.____                                       ");
				System.out.println("				|    |    _________    ____                 ");
				System.out.println("				|    |   /  _ \\__  \\ /     \\             ");
				System.out.println("				|    |__(  <_> ) __ \\|   |  \\             ");
				System.out.println("				|_______ \\____(____  /___|  /              ");
				System.out.println("				        \\/         \\/     \\/ \n\n\n      "); 
				System.out.println("				================================\n\n\n\n    ");
				System.out.println("					[1] Personal Loan               \n\n\n\n");
			    System.out.println("					[2] Business Loan               \n\n\n\n");
				System.out.println("					[3] Home Equity Loan            \n\n\n\n");
				System.out.println("					[4] Car Finance                 \n\n\n\n");
				System.out.println("					[5] Exit                        \n\n\n\n");
				
				loanController();
			}
		}
		
		public static void tax(){
			    D :while(true){	        
		        System.out.println("				___________                                ");
				System.out.println("				\\__    ___/____  ___  ___                 ");
				System.out.println("				  |    |  \\__  \\ \\  \\/  /              ");
				System.out.println("				  |    |   / __ \\_>    <                  ");
				System.out.println("				  |____|  (____  /__/\\_ \\                ");
				System.out.println("				               \\/      \\/\n\n\n          "); 
				System.out.println("				================================\n\n\n\n   ");
				System.out.println("					[1] Rent Tax               \n\n\n\n    ");
			    System.out.println("					[2] Income Tax               \n\n\n\n  ");
				System.out.println("					[3] Payable Tax            \n\n\n\n    ");
				System.out.println("					[4] Leasing                 \n\n\n\n   ");
				System.out.println("					[5] Exit                    \n\n\n\n   ");
				
				taxController();
			}
		}
		
		public static void sharemarket(){
			    E :while(true){
		        System.out.println("				  _________.__                              _____                __           __                  ");
				System.out.println("				 /   _____/|  |__ _____ _______   ____     /     \\ _____ _______|  | __ _____/  |_               ");
				System.out.println("				 \\_____  \\ |  |    \\__  \\_  __ \\_/ __ \\   /  \\ /  \\ __  \\_  __ \\  |/ // __ \\   __\\    ");
				System.out.println("				 /        \\|   Y  \\/ __ \\|  | \\/\\  ___/  /    Y    \\/ __ \\|  | \\/    <\\  ___/|  |        ");
				System.out.println("				/_______  /|___|  (____  /__|    \\___  > \\____|__  (____  /__|  |__|_ \\___  >__|               ");
				System.out.println("				        \\/      \\/     \\/            \\/          \\/     \\/           \\/    \\/      \n\n\n ");
				System.out.println("				==========================================================================================\n\n\n\n");
				
				shareMarketCalculator();
			}
		}
		
		public static void invalidController(){
			System.out.println("\n\n\n\n				Invalid Input....Please Try Again......\n\n\n");
		}
		public static void systemController(){
			Scanner input = new Scanner(System.in);
				System.out.print("Enter an option to continue -> ");
				int num = input.nextInt();
				System.out.println("\n\n\n");
				
				switch(num){
					case 1: deposit();
					        break;
					case 2: loans();
					        break;
					case 3: tax();
					        break;
					case 4: sharemarket();
					        break;
					case 5: System.out.println("\n\n\n\n"); 
				            System.out.println("				Thank you ! Come Again......\n\n\n");
				            System.exit(0);
				   default:invalidController();
			   }
		   } 
			public static void depositController(){
				Scanner input = new Scanner(System.in);
				 	 
                 System.out.print("Enter an option to continue -> ");
                  int num1 = input.nextInt();  
                 System.out.println("\n\n\n");
                 
                 switch(num1){ 
					 case 1: saving();
					         break;
					 case 2: fixed();
					         break;
					 case 3: System.out.println("				Exit From Deposit............... \n\n\n");
				             system();
				    default: invalidController();
			 }
		 }	
			public static void loanController(){
				Scanner input = new Scanner(System.in);
				System.out.print("Enter an option to continue -> ");
				int loan = input.nextInt();				
				System.out.println("\n\n\n\n");
				
				switch (loan){
					case 1: personal();
					        break;
					case 2: business();
					        break;
					case 3: home();
					        break;
					case 4: car();
					        break;
					case 5: System.out.println("				Exit From Loan.............. \n\n\n");
					        system();
				  default : invalidController();
			  }
		  }	
		public static void taxController(){
			Scanner input = new Scanner(System.in);
				System.out.print("Enter an option to continue -> ");
				int tax = input.nextInt();
				System.out.println("\n\n\n\n");
				
				switch (tax){
					case 1:rent();
					       break;
					case 2:income();
					       break;
					case 3:payable();
					       break;
					case 4:leasing();
					       break;
					case 5:System.out.println("				Exit From Tax.............. \n\n\n");
					       system();
				  default : invalidController();
			}
		}
	public static void saving(){
		System.out.println("				  _________           .__                          _____                                   __                   ");   
		System.out.println(" 				 /   _____/____ ___  _|__| ____    ____  ______   /  _  \\   ____  ____  ____  __ __  _____/  |_                "); 
		System.out.println("				 \\_____  \\__    \\  \\/ /  |/    \\  / ___\\/  ___/  /  /_\\  \\_/ ___\\/ ___\\/  _ \\|  |  \\/    \\   __\\  ");
		System.out.println("				 /        \\/ __  \\   /|  |   |  \\/ /_/  >___ \\  /    |    \\  \\__\\  \\__(  <_> )  |  /   |  \\  |         ");  
		System.out.println("				/_______  (____  /\\_/ |__|___|  /\\___  /____  > \\____|__  /\\___  >___  >____/|____/|___|  /__ |             ");  
		System.out.println("				        \\/     \\/             \\//_____/     \\/          \\/     \\/    \\/                 \\/    \n\n\n    "); 
		System.out.println("				========================================================================================================\n\n\n\n");
		
		savingCalculator();
	}
			
	public static void fixed(){
		System.out.println("				___________.__                  .___    .___                         .__  __                 ");   
		System.out.println("				\\_   _____/|__|__  ___ ____   __| _/  __| _/____ ______   ____  _____|__|/  |_              "); 
		System.out.println("				 |    __)  |  \\  \\/  // __ \\ / __ |  / __ |/ __ \\____ \\ /  _ \\/  ___/  \\   __\\       ");
		System.out.println("				 |     \\   |  |>    <\\  ___// /_/ | / /_/ \\  ___/|  |_> >  <_> )___ \\|  ||  |            ");  
		System.out.println("				 \\___  /   |__/__/\\_ \\___  >____ |  \\____ |\\___  >   __/ \\____/____  >__||__|          ");  
		System.out.println("				     \\/             \\/    \\/     \\/       \\/    \\/|__|              \\/        \n\n\n  "); 
		System.out.println("				=====================================================================================\n\n\n\n");
		
		fixedCalculator();	
	}
			
	 public static void personal(){
		System.out.println("				__________                                        .__    .____                                        ");
		System.out.println("				\\______   \\ ___________  __________   ____ _____  |  |   |    |    _________    ____                ");
		System.out.println("				 |     ___// __ \\_  __ \\/  ___/  _ \\ /    \\__  \\  |  |   |    |   /  _ \\__  \\  /    \\         ");
		System.out.println("				 |    |   \\  ___/|  | \\/\\___ (  <_> )   |  \\/ __ \\|  |__ |    |__(  <_> ) __ \\|   |  \\         ");
		System.out.println("				 |____|    \\___  >__|  /____  >____/|___|  (____  /____/ |_______ \\____(____  /___|  /              ");
		System.out.println("				               \\/           \\/           \\/     \\/               \\/         \\/     \\/ \n\n\n   "); 
		System.out.println("				==============================================================================================\n\n\n\n");
		
		personalLoanCalculator();
	}
			
	public static void business(){
		System.out.println("				__________             .__                              .____                                         ");
		System.out.println("				\\______   \\__ __  _____|__| ____   ____   ______ ______ |    |    _________    ____                 ");
		System.out.println("				 |    |  _/  |  \\/  ___/  |/    \\_/ __ \\ /  ___//  ___/ |    |   /  _ \\__  \\  /    \\            ");
		System.out.println("				 |    |   \\  |  /\\___ \\|  |   |  \\  ___/ \\___ \\ \\___ \\  |    |__(  <_> ) __ \\|   |  \\       ");
		System.out.println("				 |______  /____//____  >__|___|  /\\___  >____  >____  > |_______ \\____(____  /___|  /               ");
		System.out.println("				        \\/           \\/        \\/     \\/     \\/     \\/          \\/         \\/     \\/ \n\n\n  "); 
		System.out.println("				==============================================================================================\n\n\n\n");
		
		businessLoanCalculator();
	}
			
	public static void home(){
		System.out.println("				  ___ ___                                            .__  __           .____                                      ");
		System.out.println("				 /   |   \\  ____   _____   ____     ____  ________ __|__|/  |_ ___.__. |    |    _________    ____               ");
		System.out.println("				/    ~    \\/  _ \\ /     \\_/ __ \\  _/ __ \\/ ____/  |  \\  \\   __<   |  | |    |   /  _ \\__  \\  /    \\     ");
		System.out.println("				\\    Y    (  <_> )  Y Y  \\  ___/  \\  ___< <_|  |  |  /  ||  |  \\___  | |    |__(  <_> ) __ \\|   |  \\        ");
		System.out.println("				 \\___|_  / \\____/|__|_|  /\\___  >  \\___  >__   |____/|__||__|  / ____| |_______ \\____(____  /___|  /         ");
		System.out.println("				       \\/              \\/     \\/       \\/   |__|               \\/              \\/         \\/     \\/ \n\n\n"); 
		System.out.println("				==============================================================================================\n\n\n\n            ");
		
		homeEquityLoan();
	}
			
	public static void car(){
		System.out.println("				___________.__                                    .____                                               ");
		System.out.println("				\\_   _____/|__| ____ _____    ____   ____  ____   |    |    _________    ____                        ");
		System.out.println("				 |    __)  |  |/    \\__  \\  /    \\_/ ___\\/ __ \\   |    |   /  _ \\__  \\  /    \\                ");
		System.out.println("				 |     \\   |  |   |  \\/ __ \\|   |  \\  \\__\\  ___/  |    |__(  <_> ) __ \\|   |  \\               ");
		System.out.println("				 \\___  /   |__|___|  (____  /___|  /\\___  >___  > |_______ \\____(____  /___|  /                    ");
		System.out.println("				     \\/            \\/     \\/     \\/     \\/    \\/          \\/         \\/     \\/ \n\n\n        ");
		System.out.println("				==============================================================================================\n\n\n\n");
		
		financeLoanCalculator();
	}
			
	public static void rent(){
		System.out.println("				__________               __    ___________                            ");
		System.out.println("				\\______   \\ ____   _____/  |_  \\__    ___/____  ___  ___           ");
		System.out.println("				 |       _// __ \\ /    \\   __\\   |    |  \\__  \\ \\  \\/  /       ");
		System.out.println("				 |    |   \\  ___/|   |  \\  |     |    |   / __ \\_>    <            ");
		System.out.println("				 |____|_  /\\___  >___|  /__|     |____|  (____  /__/\\_ \\           ");
		System.out.println("				        \\/     \\/     \\/                      \\/      \\/\n\n\n   "); 
		System.out.println("				==============================================================\n\n\n\n");
		
		rentTaxCalculator();
	}
			
	public static void income(){
		System.out.println("				.___                                     ___________                          ");
		System.out.println("				|   | ____   ____  ____   _____   ____   \\__    ___/____  ___  ___           ");
		System.out.println("				|   |/    \\_/ ___\\/  _ \\ /     \\_/ __ \\    |    |  \\__  \\ \\  \\/  /   ");
		System.out.println("				|   |   |  \\  \\__(  <_> )  Y Y  \\  ___/    |    |   / __ \\_>    <         ");
		System.out.println("				|___|___|  /\\___  >____/|__|_|  /\\___  >   |____|  (____  /__/\\_ \\        ");
		System.out.println("				         \\/     \\/            \\/     \\/                 \\/      \\/\n\n\n"); 
		System.out.println("				=====================================================================\n\n\n\n ");
		
		incomeTaxCalculator();
	}
			
	public static void payable(){
		System.out.println("				__________                     ___.   .__           ___________                           ");
		System.out.println("				\\______   \\_____  ___.__._____ \\_ |__ |  |   ____   \\__    ___/____  ___  ___         ");
		System.out.println("				 |     ___/\\__  \\<   |  |\\__  \\ | __ \\|  | _/ __ \\    |    |  \\__  \\ \\  \\/  /   ");
		System.out.println("				 |    |     / __ \\___  | / __ \\| \\_\\ \\  |_\\  ___/    |    |   / __ \\_>    <        ");
		System.out.println("				 |____|    (____  / ____|(____  /___  /____/\\___  >   |____|  (____  /__/\\_ \\          ");
		System.out.println("				                \\/\\/          \\/    \\/          \\/                 \\/      \\/\n\n\n");
		System.out.println("				==================================================================================\n\n\n\n");
		
		payableTaxCalculator();
	}
			
	public static void leasing(){
		System.out.println("				.____                        .__                                ");
		System.out.println("				|    |    ____ _____    _____|__| ____    ____                  ");
		System.out.println("				|    |  _/ __ \\__  \\  /  ___/  |/    \\  / ___\\              ");
		System.out.println("				|    |__\\  ___/ / __ \\_\\___ \\|  |   |  \\/ /_/  >           ");
		System.out.println("				|_______ \\___  >____  /____  >__|___|  /\\___  /               ");
		System.out.println("				        \\/   \\/     \\/     \\/        \\//_____/  \n\n\n     ");
		System.out.println("				========================================================\n\n\n\n");
		
		leasingCalculator();
	}
	
	public static String yesOrNo(String value){
		Scanner Scanner = new Scanner(System.in);
		System.out.print("				Do you want to stay "+value+"(y/n) : ");
		String input1 = Scanner.next();
		if(value.equals("Deposit")){
			if(input1.equals("y")){
				System.out.print("\033[H\033[2J");
				System.out.flush();
				deposit();
			}else if(input1.equals("n")){
				System.out.print("\033[H\033[2J");
				System.out.flush();
				system();
			}else{
				System.out.print("\033[H\033[2J");
				System.out.flush();
				invalidController();
				return (yesOrNo(value));
			}
		}else if(value.equals("Loan")){
			if(input1.equals("y")){
				System.out.print("\033[H\033[2J");
				System.out.flush();
				loans();
			}else if(input1.equals("n")){
				System.out.print("\033[H\033[2J");
				System.out.flush();
				system();
			}else{
				System.out.print("\033[H\033[2J");
				System.out.flush();
				invalidController();
				return (yesOrNo(value));
			}
		}else if(value.equals("Tax")){
			if(input1.equals("y")){
				System.out.print("\033[H\033[2J");
				System.out.flush();
				tax();
			}else if(input1.equals("n")){
				System.out.print("\033[H\033[2J");
				System.out.flush();
				system();
			}else{
				System.out.print("\033[H\033[2J");
				System.out.flush();
				invalidController();
				return (yesOrNo(value));
			}
		}else if(value.equals("ShareMarket")){
			if(input1.equals("y")){
				System.out.print("\033[H\033[2J");
				System.out.flush();
				sharemarket();
			}else if(input1.equals("n")){
				System.out.print("\033[H\033[2J");
				System.out.flush();
				system();
			}else{
				System.out.print("\033[H\033[2J");
				System.out.flush();
				invalidController();
				return (yesOrNo(value));
			}
		}
		return "Default value";
	}
	
			public static double amountInfo(){
				Scanner input = new Scanner(System.in);
				System.out.print("				Enter Your Amount : ");
				double amount = input.nextDouble();
				return amount;
			}
			
			public static void savingCalculator(){
				Scanner input = new Scanner(System.in);
			
				double amount = amountInfo();				
				double intmo = (amount*5)/100;
				double intye = intmo*12;
				
				System.out.println("\n\n\n");
				System.out.println("				The interest you get per month : "+intmo+"\n\n\n");
				System.out.println("\n\n\n");
				System.out.println("				The interest you get per year : "+intye+"\n\n\n");
				System.out.println("\n\n\n");
				
				String result = yesOrNo("Deposit");	
		}		
			
			public static void fixedCalculator(){
				Scanner input = new Scanner(System.in);
			
				double fixed = amountInfo();
				System.out.println("\n\n\n");
				
				System.out.print("				Enter number of Year           : ");
				double year = input.nextDouble();
				
				double fixin = (fixed*8)/100; double fixiny = fixin*12;
				
				System.out.println("\n\n\n\n");				
				System.out.println("				Interest you get per month     : "+fixin+"\n\n\n");
				System.out.println("\n\n\n");
				System.out.println("				Total amount at the End        : "+((fixiny*year)+fixed)+"\n\n\n");
				System.out.println("\n\n\n");
				
				String result = yesOrNo("Deposit");		
		}	
		public static double salaryInfo(){
			Scanner input = new Scanner(System.in);
			
			System.out.print("				Enter Your Salary : ");
			double salary = input.nextDouble();
			return salary;
		}
		
		
			public static void personalLoanCalculator(){
				Scanner input = new Scanner(System.in);
			
				double salary = salaryInfo();
				
				System.out.println("\n\n\n");
				
				if(salary>=50000){
					double maxloan = salary*5;
				System.out.println("				The maximum amount you can withdraw is "+maxloan);
				System.out.println("\n\n\n");
					
				System.out.print("				Enter your Amount : ");
				double withloan = input.nextDouble();
					
				System.out.println("\n\n\n");
					
				System.out.print("				Enter number of Months : ");
				double withlmonth = input.nextDouble();
					
				if(withloan>=200000 & withlmonth>=24){
						
				double monthinlo1 = (withloan*15)/100;
						
				System.out.println("\n\n\n");
				System.out.println("				Your monthly instalment : "+monthinlo1+"\n\n\n");
					}else if(withloan<200000 & withlmonth<24 | withloan<200000 & withlmonth>24 | withloan>=200000 & withlmonth<24){
						
				double monthinlo2 = (withloan*10)/100;
						
				System.out.println("\n\n\n");
				System.out.println("				Your monthly instalment : "+monthinlo2+"\n\n\n");
					}else{
						System.out.println("				Invalid Input...............\n\n\n");
					}
					}else if(salary<50000){
						System.out.println("\n\n\n");
						System.out.println("				You cannot get a Loan......\n\n\n");
					}
					
					String result = yesOrNo("Loan");
		}	
		
			
			public static void businessLoanCalculator(){
				Scanner input = new Scanner(System.in);
				
				System.out.print("				Enter Your Income : ");
				double income = input.nextDouble();
				
				System.out.println("\n\n\n\n"); 
							
				if(income>=50000){
					double maxbloan = income*5;
					System.out.println("				The maximum amount you can withdraw is "+maxbloan);
					
					System.out.println("\n\n\n\n");
					System.out.print("				Enter your Amount : ");
					double withbloan = input.nextDouble();
					
					System.out.println("\n\n\n\n");
					
					System.out.print("				Enter number of Months : ");
					double withblmonth = input.nextDouble();
					
					System.out.println("\n\n\n\n"); 
					
					if(withbloan>=500000 & withblmonth>=36){
						
						double monthinblo1 = (withbloan*20)/100;
						
						System.out.println("				Your monthly instalment : "+monthinblo1+"\n\n\n");
					}else if(withbloan<500000 & withblmonth<36 | withbloan<500000 & withblmonth>36 | withbloan>=500000 & withblmonth<36){
						
						double monthinblo2 = (withbloan*15)/100;
						
						System.out.println("				Your monthly instalment : "+monthinblo2+"\n\n\n");
					}else{
						System.out.println("				Invalid Input..........\n\n\n");
					}
					}else if(income<50000){
						System.out.println("\n\n\n\n");
						System.out.println("				You cannot get a Loan......\n\n\n");
					}
					
					String result = yesOrNo("Loan");
		}	
		
		
			public static void homeEquityLoan(){
				Scanner input = new Scanner(System.in);

				double salaryh = salaryInfo();
				System.out.println("\n\n\n\n");
				
				if(salaryh>=50000){
					double maxhloan = salaryh*5;
					System.out.println("				The maximum amount you can withdraw is "+maxhloan);
					System.out.println("\n\n\n\n");
					
					System.out.print("				Enter your Amount : ");
					double withhloan = input.nextDouble();
					
					System.out.println("\n\n\n\n");
					
					System.out.print("				Enter number of Months : ");
					double withhlmonth = input.nextDouble();
					
					System.out.println("\n\n\n\n");
					
					if(withhloan>500000 & withhlmonth>48){
						
						double monthinhlo1 = (withhloan*8)/100;
						
						System.out.println("				Your monthly instalment : "+monthinhlo1+"\n\n\n");
					}else if(withhloan<500000 & withhlmonth<48){
						
						double monthinhlo2 = (withhloan*6)/100;
						
						System.out.println("				Your monthly instalment : "+monthinhlo2+"\n\n\n");
					}else{
						System.out.println("				Invalid Input..........\n\n\n");
					}
					}else if(salaryh<50000){
						System.out.println("\n\n\n\n");
						System.out.println("				You cannot get a Loan.........\n\n\n");
					}
					
					String result = yesOrNo("Loan");
		}	
		
		
			public static void financeLoanCalculator(){
				Scanner input = new Scanner(System.in);
				
				System.out.print("				Enter Value of the Vehicle : ");
				double value = input.nextDouble();				
				System.out.println("\n\n\n\n");
				
				System.out.print("				Enter number of Month : ");
				double valuem = input.nextDouble();
				
				if(valuem<12){
					double loanf1 = (value*6)/100;
					System.out.println("\n\n\n\n");
					System.out.println("				Your Monthly instalment : "+loanf1+"\n\n\n");
				}else if(valuem>=12 & valuem<24){
					double loanf2 = (value*10)/100;
					System.out.println("\n\n\n\n");
					System.out.println("				Your Monthly instalment : "+loanf2+"\n\n\n");
				}else if(valuem>=24 & valuem<36){
					double loanf3 = (value*14)/100;
					System.out.println("\n\n\n\n");
					System.out.println("				Your Monthly instalment : "+loanf3+"\n\n\n");
				}else if(valuem>=36){
					double loanf4 = (value*16)/100;
					System.out.println("\n\n\n\n");
					System.out.println("				Your Monthly instalment : "+loanf4+"\n\n\n");
				}else{
					System.out.println("\n\n\n\n");
					System.out.println("				Inavlid Input...........\n\n\n");
				}
				
				String result = yesOrNo("Loan");
		}	
		
		
			public static void rentTaxCalculator(){
				Scanner input = new Scanner(System.in);
				
				System.out.print("				Enter Your Rent : ");
				double rent = input.nextDouble();    
				
				if(rent>=100000){	
					double taxre = (rent*5)/100;
				
				System.out.println("\n\n\n\n");
				System.out.println("				You have to pay Rent Tax : "+taxre+"\n\n\n");
			}else{
				System.out.println("\n\n\n\n");
				System.out.println("				You are not required to pay rent tax \n\n\n");
			}
			
			String result = yesOrNo("Tax");
	}	
	
	
			public static void incomeTaxCalculator(){
				Scanner input = new Scanner(System.in);
						
				System.out.print("				Enter your total income per Year : ");
				double insalary = input.nextDouble(); 
				
				if(insalary>1200000 & insalary<1700000){
					double intax1 = ((insalary-1200000)*6)/100;
       					
					System.out.println("\n\n\n\n");
					System.out.println("				You have to pay Income Tax per Year :"+intax1+"\n\n\n");
				}else if(insalary>=1700000 & insalary<2200000){
					double intax2 = ((insalary-1700000)*12)/100;
					double per1 = (500000*6)/100;
					
					System.out.println("\n\n\n\n");
					System.out.println("				You have to pay Income Tax per Year :"+(per1+intax2)+"\n\n\n");
				}else if(insalary>=2200000 & insalary<2700000){ 
					double intax3 = ((insalary-2200000)*18)/100;
					double per1 = (500000*6)/100;
					double per2 = (500000*12)/100;
					
					System.out.println("\n\n\n\n");
					System.out.println("				You have to pay Income Tax per Year :"+(per1+per2+intax3)+"\n\n\n");
				}else if(insalary>=2700000 & insalary<3200000){
					double intax4 = ((insalary-2700000)*24)/100;
					double per1 = (500000*6)/100;
					double per2 = (500000*12)/100;
					double per3 = (500000*18)/100;
					
					System.out.println("\n\n\n\n");
					System.out.println("				You have to pay Income Tax per Year :"+(per1+per2+per3+intax4)+"\n\n\n");
				}else if(insalary>=3200000 & insalary<3700000){
					double intax5 = ((insalary-3200000)*30)/100;
					double per1 = (500000*6)/100;
					double per2 = (500000*12)/100;
					double per3 = (500000*18)/100;
					double per4 = (500000*24)/100;
					
					System.out.println("\n\n\n\n");
					System.out.println("				You have to pay Income Tax per Year :"+(per1+per2+per3+per4+intax5)+"\n\n\n");
				}else if(insalary>=3700000){
					double intax6 = ((insalary-3700000)*36)/100;
					double per1 = (500000*6)/100;
					double per2 = (500000*12)/100;
					double per3 = (500000*18)/100;
					double per4 = (500000*24)/100;
					double per5 = (500000*30)/100;
					
					System.out.println("\n\n\n\n");
					System.out.println("				You have to pay Income Tax per Year :"+(per1+per2+per3+per4+per5+intax6)+"\n\n\n");
				}else if(insalary<=1200000){
					
					System.out.println("\n\n\n\n");
					System.out.println("				You are not required to pay Income Tax \n\n\n");
				}else{
					System.out.println("				Invalid Input................ \n\n\n");
				}
				
				String result = yesOrNo("Tax");
		}	
		
				
			public static void payableTaxCalculator(){
				Scanner input = new Scanner(System.in);
				
				System.out.print("				Enter your employee payment per month : ");
				double payabtax = input.nextDouble();
				
				if(payabtax>100000 & payabtax<141667){
					double paytax1 = ((payabtax-100000)*6)/100;
					
					System.out.println("\n\n\n\n");
					System.out.println("				You have to pay Income Tax per Year :"+paytax1+"\n\n\n");
				}else if(payabtax>=141667 & payabtax<183333){
					double paytax2 = ((payabtax-141667)*12)/100;
					double pay1 = (41667*6)/100;
					
					System.out.println("\n\n\n\n");
					System.out.println("				You have to pay Income Tax per Year :"+(pay1+paytax2)+"\n\n\n");
				}else if(payabtax>183333 & payabtax<225000){
					double paytax3 = ((payabtax-183333)*18)/100;
					double pay1 = (41667*6)/100;
					double pay2 = (41667*12)/100;
					
					System.out.println("\n\n\n\n");
					System.out.println("				You have to pay Income Tax per Year :"+(pay1+pay2+paytax3)+"\n\n\n");
				}else if(payabtax>225000 & payabtax<266667){
					double paytax4 = ((payabtax-270000)*24)/100;
					double pay1 = (41667*6)/100;
					double pay2 = (41667*12)/100;
					double pay3 = (41667*18)/100;
					
					System.out.println("\n\n\n\n");
					System.out.println("				You have to pay Income Tax per Year :"+(pay1+pay2+pay3+paytax4)+"\n\n\n");
				}else if(payabtax>266667 & payabtax<308333){
					double paytax5 = ((payabtax-320000)*30)/100;
					double pay1 = (41667*6)/100;
					double pay2 = (41667*12)/100;
					double pay3 = (41667*18)/100;
					double pay4 = (41667*24)/100;
					
					System.out.println("\n\n\n\n");
					System.out.println("				You have to pay Income Tax per Year :"+(pay1+pay2+pay3+pay4+paytax5)+"\n\n\n");
				}else if(payabtax>=308333){
					double paytax6 = ((payabtax-370000)*36)/100;
					double pay1 = (41667*6)/100;
					double pay2 = (41667*12)/100;
					double pay3 = (41667*18)/100;
					double pay4 = (41667*24)/100;
					double pay5 = (41667*30)/100;
					
					System.out.println("\n\n\n\n");
					System.out.println("				You have to pay Income Tax per Year :"+(pay1+pay2+pay3+pay4+pay5+paytax6)+"\n\n\n");
				}else if(payabtax<=100000){
					
					System.out.println("\n\n\n\n");
					System.out.println("				You are not required to pay Payable Tax \n\n\n");
				}else{
					System.out.println("				Invalid Input.............. \n\n\n");
				}
				
				String result = yesOrNo("Tax");
		}
		
		
			public static void leasingCalculator(){
				Scanner input = new Scanner(System.in);
				
				System.out.print("				Enter the monthly lease payment amount you can afford :  "           );
				double leasamo = input.nextDouble();
				
				System.out.println("\n\n\n\n");			
				System.out.print("				Enter number of Years : ");
				double leasye = input.nextDouble();
				
				System.out.println("\n\n\n\n");	
				System.out.print("				Enter annual interest rate : ");
				double leasin = input.nextDouble();
				double leasmon =leasye*12;
				
				double leasyei = ((leasamo*12)*leasin*leasye)/100;
				double leasava = (leasamo*leasmon)-leasyei;
				
				System.out.println("\n\n\n\n");				
				System.out.println("				You can get Lease Amount : "+leasava+"\n\n\n");
				
				String result = yesOrNo("Tax");
		}	
		
			
			public static void shareMarketCalculator(){
				Scanner input = new Scanner(System.in);
				
				System.out.print("				Enter your Amount : ");
				double shareamo = input.nextDouble();
				
				double shareava = shareamo/80;
				System.out.println("\n\n\n\n"); 
				System.out.print("				Number of shares available : "+shareava);
				
				double sharediv = shareava*74;
				System.out.println("\n\n\n\n");  
				System.out.println("				Annual divident : "+sharediv+"\n\n\n");
				
				String result = yesOrNo("ShareMarket");
		}	
		
			
	public static void main(String args[]){
		
		system();
	}
}
