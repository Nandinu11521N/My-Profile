import java.util.*; 
class BookShop{
	public static  void main(String []args){
		Scanner input=new Scanner(System.in);
		
        System.out.println("       __________               __       _________.__");
        System.out.println("       \\______   \\ ____   ____ |  | __  /   _____/|  |__   ____ ______");
        System.out.println("        |    |  _//  _ \\ /  _ \\|  |/ /  \\_____  \\ |  |  \\ /  _ \\\\____ \\");
        System.out.println("        |    |   (  <_> |  <_> )    <   /        \\|   Y  (  <_> )  |_> >");
        System.out.println("        |______  /\\____/ \\____/|__|_ \\ /_______  /|___|  /\\____/|   __/");
        System.out.println("               \\/                   \\/         \\/      \\/       |__|");
        System.out.println("                                                                                             ");
        System.out.println("  ===========================================================================================");
        
        
        System.out.println("");
        System.out.println("");
        System.out.println("");
        System.out.println("");
        
        System.out.print("\t\t Enter Date          : ");
        String date=input.next();
        System.out.println("");
        System.out.println("");
        System.out.println(""); 
        
        System.out.print("\t\t Customer Number     : ");
        int number=input.nextInt();
        System.out.println("");
        System.out.println("");
        System.out.println("");
        
        System.out.print("\t\t Enter Customer Name : ");
        String name=input.next();
        System.out.println("");
        System.out.println("");
        System.out.println("");
        
        
        
        System.out.println("         _________      .__                  .__    .___  __                         ");
        System.out.println("        /   _____/ ____ |  |__   ____   ____ |  |   |   |/  |_  ____   _____   ______");
        System.out.println("        \\_____  \\_/ ___\\|  |  \\ /  _ \\ /  _ \\|  |   |   \\   __\\/ __ \\ /     \\ /  ___/");
        System.out.println("        /        \\  \\___|   Y  (  <_> |  <_> )  |__ |   ||  | \\  ___/|  Y Y  \\\\___ \\ ");
        System.out.println("       /_______  /\\___  >___|  /\\____/ \\____/|____/ |___||__|  \\___  >__|_|  /____  >");
        System.out.println("               \\/     \\/     \\/                                    \\/      \\/     \\/ ");        
        System.out.println("                                                                                     ");
        System.out.println(" ===========================================================================================");
        
        
        
        System.out.println("                                                                                     ");
        System.out.println("                                                                                     ");
        System.out.println("                                                                                     ");
        System.out.println("                                                                                     ");
        
        System.out.print("\t\t CR Book (QTY)          " );
        int item1=input.nextInt();
        System.out.println("");
        System.out.println("");
        System.out.println("");
        
        System.out.print("\t\t Pen (QTY)              " );
        int item2=input.nextInt();
        System.out.println("");
        System.out.println("");
        System.out.println("");
        
        System.out.print("\t\t Pencil (QTY)           " );
        int item3=input.nextInt();
        System.out.println("");
        System.out.println("");
        System.out.println("");
        
        System.out.print("\t\t Eraser (QTY)           " );
        int item4=input.nextInt();
        System.out.println("");
        System.out.println("");
        System.out.println("");
        
        System.out.print("\t\t Pencil Box (QTY)       " );
        int item5=input.nextInt();
        System.out.println("");
        System.out.println("");
        System.out.println("");
        
        System.out.print("\t\t Glue Bottle (QTY)      " );
        int item6=input.nextInt();
        System.out.println("");
        System.out.println("");
        System.out.println("");
        
        System.out.print("\t\t Ruler-(MEDIUM) (QTY)   " );
        int item7=input.nextInt();
        System.out.println("");
        System.out.println("");
        System.out.println("");
        
        
        System.out.println("       ________   _____  _____.__               .___  __                         ");
        System.out.println("       \\_____  \\_/ ____\\/_   |  | ____  ____   |   |/  |_  ____   _____   ______");
        System.out.println("        /   |   \\   __\\ |   |  |/ ___\\/ __ \\   |   \\   __\\/ __ \\ /     \\ /  ___/");
        System.out.println("       /    |    \\  |    |   |  \\  \\__\\  ___/  |   ||  | \\  ___/|  Y Y  \\\\___ \\ ");
        System.out.println("       \\_______  /__|    |___|  /\\___  >___  > |___||__|  \\___  >__|_|  /____  >");
        System.out.println("               \\/             \\/     \\/    \\/                 \\/      \\/     \\/ ");
        System.out.println("                                                                                   ");
        System.out.println(" ===========================================================================================");
        
        System.out.println("                                                                                   ");
        System.out.println("                                                                                   ");
        System.out.println("                                                                                   ");
        
        
        System.out.print("\t\t Calculator (QTY)          " );
        int item8=input.nextInt();
        System.out.println("");
        System.out.println("");
        System.out.println("");
        
        System.out.print("\t\t Highlighters (QTY)        " );
        int item9=input.nextInt();
        System.out.println("");
        System.out.println("");
        System.out.println("");
        
        System.out.print("\t\t Cardboard Files (QTY)     " );
        int item10=input.nextInt();
        System.out.println("");
        System.out.println("");
        System.out.println("");
        
        
        System.out.println("       ________   __  .__                   .___  __                         ");
        System.out.println("       \\_____  \\_/  |_|  |__   ___________  |   |/  |_  ____   _____   ______");
        System.out.println("        /   |   \\   __\\  |  \\_/ __ \\_  __ \\ |   \\   __\\/ __ \\ /     \\ /  ___/");
        System.out.println("       /    |    \\  | |   Y  \\  ___/|  | \\/ |   ||  | \\  ___/|  Y Y  \\\\___ \\ ");
        System.out.println("       \\_______  /__| |___|  /\\___  >__|    |___||__|  \\___  >__|_|  /____  >");
        System.out.println("               \\/          \\/     \\/                       \\/      \\/     \\/ ");
        System.out.println("                                                                             ");
        System.out.println(" =========================================================================================");
        
        System.out.println("                                                                             ");
        System.out.println("                                                                             ");
        System.out.println("                                                                             ");
        
        
        System.out.print("\t\t Water Bottle (QTY)        " );
        int item11=input.nextInt();
        System.out.println("");
        System.out.println("");
        System.out.println("");
         
        System.out.print("\t\t Lunch Box (QTY)           " );
        int item12=input.nextInt();
        System.out.println("");
        System.out.println("");
        System.out.println("");
        
        System.out.print("\t\t School Bag (QTY)          " );
        int item13=input.nextInt();
        System.out.println("");
        System.out.println("");
        System.out.println("");
        
        
        int a=80;
        int b=20;
        int c=15;
        int d=10; 
        int e=40;
        int f=100;
        int g=230;
        int h=250;
        int i=250;
        int j=1000;
        int k=10;
        int l=50;
        int m=25;
        int total=item1*a+item2*b+item3*c+item4*d+item5*e+item6*f+item7*g+item8*h+item9*i+item10*j+item11*k+item12*l+item13*m;
        double discount=total*10/100;
        
        double price=total-discount;
        
        System.out.println("+----------------------------------------------------------------------------------------------------------------------------------+");
        System.out.println("|                                                                                                                                  |");
        System.out.println("|       				__________               __       _________.__                                             |");
        System.out.println("|       				\\______   \\ ____   ____ |  | __  /   _____/|  |__   ____ ______                            |");
        System.out.println("|        				|    |  _//  _ \\ /  _ \\|  |/ /  \\_____  \\ |  |  \\ /  _ \\\\____ \\                            |");
        System.out.println("|        				|    |   (  <_> |  <_> )    <   /        \\|   Y  (  <_> )  |_> >                           |");
        System.out.println("|        				|______  /\\____/ \\____/|__|_ \\ /_______  /|___|  /\\____/|   __/                            |");
        System.out.println("|               				\\/                   \\/         \\/      \\/       |__|                              |");
        System.out.println("+----------------------------------------------------------------------------------------------------------------------------------+");
        System.out.printf("| Tel  : %-68d                                                      |\n", number);
        System.out.printf("| Name : %-103s Date : %-11s|\n", name, date);
        System.out.println("+----------------------------------------------------------------------------------------------------------------------------------+");
        System.out.println("|              Items              |          QTY          |             Unit Price             |               Price               |");
        System.out.println("+----------------------------------------------------------------------------------------------------------------------------------+");
        System.out.println("|                                 |                       |                                    |                                   |");        
        System.out.printf("|           %-21s |           %-11d |                %-19d |               %-19d |\n", "CR Book", item1, a, item1 * a);
        System.out.println("|                                 |                       |                                    |                                   |");        
        System.out.printf("|           %-21s |           %-11d |                %-19d |               %-19d |\n", "Pen", item2, b, item2 * b);
        System.out.println("|                                 |                       |                                    |                                   |");        
        System.out.printf("|           %-21s |           %-11d |                %-19d |               %-19d |\n", "Pencil", item3, c, item3 * c);
        System.out.println("|                                 |                       |                                    |                                   |");        
        System.out.printf("|           %-21s |           %-11d |                %-19d |               %-19d |\n", "Erasers", item4, d, item4 * d);
        System.out.println("|                                 |                       |                                    |                                   |");        
        System.out.printf("|           %-21s |           %-11d |                %-19d |               %-19d |\n", "Glue", item5, e, item5 * e);
        System.out.println("|                                 |                       |                                    |                                   |");        
        System.out.printf("|           %-21s |           %-11d |                %-19d |               %-19d |\n", "Pencil Box", item6, f, item6 * f);
        System.out.println("|                                 |                       |                                    |                                   |");        
        System.out.printf("|           %-21s |           %-11d |                %-19d |               %-19d |\n", "Water Bottle", item7, g, item7 * g);
        System.out.println("|                                 |                       |                                    |                                   |");        
        System.out.printf("|           %-21s |           %-11d |                %-19d |               %-19d |\n", "Lunch Box", item8, h, item8 * h);
        System.out.println("|                                 |                       |                                    |                                   |");        
        System.out.printf("|           %-21s |           %-11d |                %-19d |               %-19d |\n", "Calculator", item9, i, item9 * i);
        System.out.println("|                                 |                       |                                    |                                   |");        
        System.out.printf("|           %-21s |           %-11d |                %-19d |               %-19d |\n", "School Bag", item10, j, item10 * j);
        System.out.println("|                                 |                       |                                    |                                   |");        
        System.out.printf("|           %-21s |           %-11d |                %-19d |               %-19d |\n", "Ruler", item11, k, item11 * k);
        System.out.println("|                                 |                       |                                    |                                   |");        
        System.out.printf("|           %-21s |           %-11d |                %-19d |               %-19d |\n", "Highlighters", item12, l, item12 * l);
        System.out.println("|                                 |                       |                                    |                                   |");        
        System.out.printf("|           %-21s |           %-11d |                %-19d |               %-19d |\n", "CardBoard File", item13, m, item13 * m);
        System.out.println("|                                 |                       |                                    |                                   |");        
        System.out.println("+----------------------------------------------------------------------------------------------------------------------------------+");
        System.out.printf("|                                 |          Total                                             |               %-19d |\n", total);
        System.out.println("|                                 |------------------------------------------------------------------------------------------------|");
        System.out.printf("|                                 |          Discount (10%%)                                    |               %-19f |\n", discount);
        System.out.println("|----------------------------------------------------------------------------------------------------------------------------------|");
        System.out.printf("|                                 |          Price                                             |               +%-18f |\n", price);
        System.out.println("+----------------------------------------------------------------------------------------------------------------------------------+");
        
        
        System.out.println("                                                            ");
        System.out.println("                                                           ");
        System.out.println("                                                           ");        
        System.out.println("       __________        .__                              ");
        System.out.println("       \\______   \\_____  |  | _____    ____   ____  ____  ");
        System.out.println("        |    |  _/\\__  \\ |  | \\__  \\  /    \\_/ ___\\/ __ \\ ");
        System.out.println("        |    |   \\ / __ \\|  |__/ __ \\|   |  \\  \\__\\  ___/ ");
        System.out.println("        |______  /(____  /____(____  /___|  /\\___  >___  >");
        System.out.println("               \\/      \\/          \\/     \\/     \\/    \\/ ");
        System.out.println("                                                           ");
        System.out.println(" ====================================================================================");
        System.out.println("                                                           ");
        System.out.println("                                                           ");
        System.out.println("                                                           "); 
        
        
        System.out.print("\t\t Enter Customer Given Amount - " );
        int cash=input.nextInt();
        System.out.println("");
        System.out.println("");
        System.out.println("");
        
        double change=cash-price;
        
        int z=(int)change/5000;
        int z1=(int)change%5000;
        int y=z1/2000;
        int y1=z1%2000;
        int x=y1/1000;
        int x1=y1%1000;
        int w=x1/500;
        int w1=x1%500;
        int v=w1/200;
        int v1=w1%200;
        int u=v1/100;
        int u1=v1%100;
        int t=u1/50;
        int t1=u1%50;
        int s=t1/20;
        int s1=t1%20;
        int r=s1/10;
        int r1=s1%10;
        int q=r1/5;
        int q1=r1%5;
        int p=q1/2;
        int p1=q1%2;
        int o=p1/1;
        int o1=p1%1;
        
        System.out.printf("\t\t\t+-----------------------------------------------------------------+\n");
        System.out.printf("\t\t\t|          NET AMOUNT          |          %-20.2f    |\n", price); 
        System.out.printf("\t\t\t+-----------------------------------------------------------------+\n");
        System.out.printf("\t\t\t|          CASH                |          %-20d    |\n", cash); 
        System.out.printf("\t\t\t+-----------------------------------------------------------------+\n");
        System.out.printf("\t\t\t|          CHANGE              |          %-20.2f    |\n", change);
        System.out.printf("\t\t\t+-----------------------------------------------------------------+\n");
        System.out.println("");               
        System.out.println("");               
        System.out.println("");
        
                       
        System.out.printf("\t\t\t+-----------------------------------------------------------------+\n");
        System.out.printf("\t\t\t|          VALUE               |                NO                |\n");
        System.out.printf("\t\t\t+-----------------------------------------------------------------+\n");
        System.out.printf("\t\t\t|        RS.5000               |           %-22d |\n", z);
        System.out.printf("\t\t\t+-----------------------------------------------------------------+\n");
        System.out.printf("\t\t\t|        RS.2000               |           %-22d |\n", y);  
        System.out.printf("\t\t\t+-----------------------------------------------------------------+\n");
        System.out.printf("\t\t\t|        RS.1000               |           %-22d |\n", x);
        System.out.printf("\t\t\t+-----------------------------------------------------------------+\n");
        System.out.printf("\t\t\t|        RS.500                |           %-22d |\n", w);
        System.out.printf("\t\t\t+-----------------------------------------------------------------+\n");
        System.out.printf("\t\t\t|        RS.200                |           %-22d |\n", v);
        System.out.printf("\t\t\t+-----------------------------------------------------------------+\n");
        System.out.printf("\t\t\t|        RS.100                |           %-22d |\n", u);
        System.out.printf("\t\t\t+-----------------------------------------------------------------+\n");
        System.out.printf("\t\t\t|        RS.50                 |           %-22d |\n", t);
        System.out.printf("\t\t\t+-----------------------------------------------------------------+\n");
        System.out.printf("\t\t\t|        RS.20                 |           %-22d |\n", s);
        System.out.printf("\t\t\t+-----------------------------------------------------------------+\n");
        System.out.printf("\t\t\t|        Coin 10               |           %-22d |\n", r);
        System.out.printf("\t\t\t+-----------------------------------------------------------------+\n");
        System.out.printf("\t\t\t|        Coin 5                |           %-22d |\n", q);
        System.out.printf("\t\t\t+-----------------------------------------------------------------+\n");
        System.out.printf("\t\t\t|        Coin 2                |           %-22d |\n", p);
        System.out.printf("\t\t\t+-----------------------------------------------------------------+\n");
        System.out.printf("\t\t\t|        Coin 1                |           %-22d |\n", o);
        System.out.printf("\t\t\t+-----------------------------------------------------------------+\n");
                             
        
   
        
        
    }
}
